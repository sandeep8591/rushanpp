package com.cg.ac.service;

import java.util.ArrayList;

import com.cg.ac.dao.AccountDao;
import com.cg.ac.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
AccountDao accountDao= new AccountDaoImpl();
	@Override
	public ArrayList<String> showAccountList() {
		
		return accountDao.showAccountList();
	}

}
