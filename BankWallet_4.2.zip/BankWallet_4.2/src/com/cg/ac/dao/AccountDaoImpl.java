package com.cg.ac.dao;

import java.util.ArrayList;

import com.cg.ac.util.Collection;

public class AccountDaoImpl implements AccountDao {

	Collection collection= new Collection();
	@Override
	public ArrayList<String> showAccountList() {
		
		return collection.showAccountList();
	}

}
