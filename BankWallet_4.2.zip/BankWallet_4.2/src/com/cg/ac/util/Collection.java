package com.cg.ac.util;

import java.util.ArrayList;

public class Collection {
	
		private ArrayList<String> accountList;

		public ArrayList<String> getAccountList() {
			return accountList;
		}

		public void setAccountList(ArrayList<String> accountList) {
			this.accountList = accountList;
		}

		public ArrayList<String> showAccountList(){
			return accountList;
			
		}
			

}
