package com.cg.ac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.ac.entity.Account;
import com.cg.ac.service.AccountService;



@Controller
public class AccountController {
	@Autowired
	private AccountService accountService;
	Account account=new Account();
	@RequestMapping("/index")
	public String getHomePage(Model model)
	{
		
		model.addAttribute("account", new Account());
		return "index";
	}
	
	
	@RequestMapping("/save")
	public String saveAccount(Model model) {
		model.addAttribute("accountList", accountService.loadAll());
		model.addAttribute("accountType",new String[]
				{"Current","Savings","Other"}
				);
		model.addAttribute("account", account);

		return "save";
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	
	public String saveAccount(@ModelAttribute("account") Account account,Model model)
	{
		
		account =  accountService.save(account);
	
		model.addAttribute("message","Account No: "+account.getAccountNo()+" added Successfully");
		return "redirect:/save.html";
	}

@RequestMapping("/show")
public String showBalance(Model model) {
	
	model.addAttribute("account", account);

	return "show";
}

@RequestMapping(value="/show",method=RequestMethod.POST)
public String showBalance(@ModelAttribute("account") Account account,Model model) 
{
	account =  accountService.showBalance(account);
	model.addAttribute("balance","Account No: "+account.getAccountNo()+" Balance is"+account.getBalance());
	return "redirect:/show.html";
	
}

@RequestMapping("/deposite")
public String deposite(Model model) {
	
	model.addAttribute("account", account);

	return "deposite";
}

@RequestMapping(value="/deposite",method=RequestMethod.POST)
public String deposite(@ModelAttribute("account") Account account,Model model)
{
	accountService.deposite(account);
	model.addAttribute("deposite","Account No: "+account.getAccountNo()+" Balance is"+account.getBalance()+" Deposited");
	return "redirect:/deposite.html";
	
}

@RequestMapping("/withdraw")
public String withDraw(Model model) {
	
	model.addAttribute("account", account);

	return "withdraw";
}

@RequestMapping(value="/withdraw",method=RequestMethod.POST)
public String withDraw(@ModelAttribute("account") Account account,Model model)
{
	accountService.withDraw(account);
	model.addAttribute("withdraw","Account No: "+account.getAccountNo()+" Balance is"+account.getBalance()+" Deducted");
	return "redirect:/withdraw.html";
	
}

@RequestMapping("/transfer")
public String fundTransfer(Model model) {
	
	model.addAttribute("account", account);

	return "transfer";
}

@RequestMapping(value="/transfer",method=RequestMethod.POST)
public String fundTransfer(@ModelAttribute("account") Account account,Model model,int accountNo,int accountNo1, int amount)
{
	accountService.fundTransfer(accountNo, accountNo1, amount);
	return "redirect:/transfer.html";
	
}

}
