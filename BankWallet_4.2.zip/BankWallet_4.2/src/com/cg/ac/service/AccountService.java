package com.cg.ac.service;

import java.util.ArrayList;

public interface AccountService {
	public ArrayList<String> showAccountList();

}
