package com.cg.ac.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.ac.entity.Account;

@Repository
public class AccountDaoImpl implements AccountDao {
	@PersistenceContext
	private EntityManager entityManager;
	Account account= new Account();
	@Override
	public Account save(Account account) {
		Random rand = new Random();
		int randomAc = rand.nextInt(900000000) + 1000000000;
		account.setAccountNo(randomAc);
		
		entityManager.persist(account);
		entityManager.flush();
		return account;
		
	}

	@Override
	public List<Account> loadAll() {
		TypedQuery<Account> querry=entityManager.createQuery("select a from Account a",Account.class);
		return querry.getResultList();
	}

	@Override
	public Account showBalance(Account account) {
		if(entityManager.find(Account.class, account.getAccountNo())!=null)
		{
			account=entityManager.find(Account.class, account.getAccountNo());
			System.out.println(account.getBalance());
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		return account;
	}

	@Override
	public Account deposite(Account account1) {
		
		if(entityManager.find(Account.class, account1.getAccountNo())!=null)
		{	int amount=account.getBalance();
			account=entityManager.find(Account.class, account1.getAccountNo());
			amount=amount+account1.getBalance();
			account.setBalance(amount);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		return account;
	}

	@Override
	public Account withDraw(Account account1) {
		if(entityManager.find(Account.class, account1.getAccountNo())!=null)
		{	int amount=account.getBalance();
			account=entityManager.find(Account.class, account1.getAccountNo());
			amount=account1.getBalance()-amount;
			account.setBalance(amount);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		return account;
		
	}

	@Override
	public Account fundTransfer(int accountNo, int accountNo1, int amount) {
		if(entityManager.find(Account.class, accountNo)!=null && entityManager.find(Account.class, accountNo1)!=null )
		{
			
			account=entityManager.find(Account.class, accountNo);
			
			if(account.getBalance()>amount)
			{
				int amount1=account.getBalance()-amount;
				account.setBalance(amount1);
				
				account=entityManager.find(Account.class, accountNo1);
				amount1=account.getBalance()+amount;
				account.setBalance(amount1);
				System.out.println("Trasaction successfull!!");
				
			}
			else
			{
				System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());
			}
		}
		else {
			System.out.println("User not exist");
		}
		
		
		
		return account;
	
	}
	

}
