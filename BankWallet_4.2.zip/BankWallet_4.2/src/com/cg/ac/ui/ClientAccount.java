package com.cg.ac.ui;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.ac.entity.Account;
import com.cg.ac.util.Collection;

public class ClientAccount {

	public static void main(String[] args) {
		Resource res= new ClassPathResource("account.xml");
		BeanFactory factory= new XmlBeanFactory(res);
		Collection collection= (Collection) factory.getBean("collection");
		List acc= collection.showAccountList();
		System.out.println(acc);
		Account account= (Account) factory.getBean("account");
		System.out.println(account.getContactNo());

	}

}
