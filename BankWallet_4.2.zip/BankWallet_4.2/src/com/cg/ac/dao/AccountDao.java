package com.cg.ac.dao;

import java.util.ArrayList;

public interface AccountDao {
	public ArrayList<String> showAccountList();

}
