package com.cg.ac.dao;

import java.util.List;

import com.cg.ac.entity.Account;

public interface AccountDao {
	public abstract Account save(Account account);
	public abstract List<Account> loadAll();
	public Account showBalance(Account account);
	public Account deposite(Account account);
	public Account withDraw(Account account);
	public Account fundTransfer(int accountNo,int accountNo1, int amount);

}
